<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div>
 
    <?php echo $__env->yieldContent('content'); ?>

</div>



<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Cours\Projets\coiffeur\resources\views/master.blade.php ENDPATH**/ ?>