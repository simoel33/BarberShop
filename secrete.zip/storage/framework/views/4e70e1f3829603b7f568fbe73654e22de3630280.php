



<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Admin</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
           

            <li>
              
              <?php if(Session::has('message') || Session::has('modifier') ): ?>
              <div class="card card-success">
                <div class="card-header">
                  <h3 class="card-title">Succes</h3>
  
                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
                    </button>
                  </div>
                  <!-- /.card-tools -->
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                  <?php echo e(Session::get('message')); ?>

                </div>
           
                </div>
                <?php endif; ?>
            </li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

  

<div class="card">
              <div class="card-header">
                <h3 class="card-title">Listes des Servies</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Nom du Service </th>
                    <th>Prix</th>
                    <th>date de creation</th>
                    <th>Option 1</th>
                    <th>Option 2</th>
                    <th>Option 3</th>
                    <th>Option 4</th>
                    <th>Option 5</th>
                    <th>Modifier</th>
                    <th>Supprimer</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                  <tr>
                    <td><?php echo e($service->nom); ?></td>
                    <td><?php echo e($service->prix); ?> € </td>
                    <td><?php echo e($service->created_at); ?></td>
                    <td><?php echo e($service->option1); ?></td>
                    <td><?php echo e($service->option2); ?></td>
                    <td><?php echo e($service->option3); ?></td>
                    <td><?php echo e($service->option4); ?></td>
                    <td><?php echo e($service->option5); ?></td>
                    <td style="text-align: center;"> <a href="/modifier/<?php echo e($service->id); ?>" class="button delete-confirm"> <i class="far fa-edit" style="color: royalblue; "></i></a></td>
                    <td style="text-align: center;" ><a href="supprimer/<?php echo e($service->id); ?>"><i class="fas fa-trash-alt" style="color: red;text-align: center;" ></i></a> </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Cours\Projets\coiffeur\resources\views/admin/allservices.blade.php ENDPATH**/ ?>