


<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Admin</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
             
  
              <li>
                
                <?php if(Session::has('message') || Session::has('modifier') ): ?>
                <div class="card card-success">
                  <div class="card-header">
                    <h3 class="card-title">Succes</h3>
    
                    <div class="card-tools">
                      <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
                      </button>
                    </div>
                    <!-- /.card-tools -->
                  </div>
                  <!-- /.card-header -->
                  <div class="card-body">
                    <?php echo e(Session::get('message')); ?>

                  </div>
             
                  </div>
                  <?php endif; ?>
              </li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
  
    
  
  <div class="card">
                <div class="card-header">
                  <h3 class="card-title">Listes des Messages</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                      <th>Nom Client </th>
                      <th>Prenom Client</th>
                      <th>date de Message</th>
                      <th>Num Tele</th>
                      <th>Email</th>
                      <th>Message</th>
                      <th>Supprimer</th>
                    </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr>
                      
                      <td><?php echo e($message->nom); ?></td>
                      <td><?php echo e($message->prenom); ?></td>
                      <td><?php echo e($message->created_at); ?></td>
                      <td><?php echo e($message->phone); ?></td>
                      <td><?php echo e($message->email); ?></td>
                      <td><?php echo e($message->message); ?></td>
                      <td style="text-align: center;" ><a href="supprimermessage/<?php echo e($message->id); ?>"><i class="fas fa-trash-alt" style="color: red;text-align: center;" ></i></a> </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </table>
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Cours\Projets\coiffeur\resources\views/admin/Showmessages.blade.php ENDPATH**/ ?>