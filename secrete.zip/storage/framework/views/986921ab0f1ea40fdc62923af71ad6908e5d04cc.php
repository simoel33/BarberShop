

<?php $__env->startSection('content'); ?>

<section class="ftco-section ftco-pricing " style="background-image: url(<?php echo e(asset('front/images/bg-1.jpg')); ?> );  background-size: cover;  background-repeat: no-repeat;">

    <div class="container">
        <div class="row justify-content-center pb-3">
            <div class="col-md-10 heading-section text-center ftco-animate">

                <h2 class="mb-4" style="color: white;">GALLERY </h2>
            </div>
        </div>
        <div class="row">

        </div>
    </div>
</section>

<section class="services-section ftco-section">
<div class="container">
  <div class="row justify-content-center pb-3">
  <div class="col-md-10 heading-section text-center ftco-animate">
      <span class="subheading">Instagram</span>
    <h3 class="mb-4">Découvrez le salon de Coiffure Homme & Barbier en image, et abonnez-vous sur Instagram !
</h3>
    <p><a href="#" target="_blank"</a><img src="http://assets.stickpng.com/images/580b57fcd9996e24bc43c521.png"  height="60px"  width="60px"></a></p>
    <p>votre satisfaction est toujours notre plus grande préoccupation. </p>
  </div>
</div>

</div>
</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Cours\Projets\coiffeur\resources\views/galery.blade.php ENDPATH**/ ?>