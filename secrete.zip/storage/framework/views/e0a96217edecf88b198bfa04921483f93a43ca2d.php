

<?php $__env->startSection('content'); ?>

<section class="ftco-section ftco-pricing " style="background-image: url(<?php echo e(asset('front/images/barbregauche.jpg')); ?> );  background-size: cover;  background-repeat: no-repeat;">
 
    <div class="container">
        <div class="row justify-content-center pb-3">
  <div class="col-md-10 heading-section text-center ftco-animate">
 
    <h2 class="mb-4" style="color: blanchedalmond">Tarifs Barbe</h2>
  </div>
</div>
<div class="row">
    <?php $__currentLoopData = $forfaits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forfait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
    
    <div class="col-md-3 ftco-animate">
        <div class="pricing-entry pb-5 text-center">
            <div>
                <h2 style="color: #340E0E; font-weight: bold;  background-color: lightgrey;" class="mb-4" style="color: white; font-weight: bold;"><?php echo e($forfait->nom); ?></h2>
                <p><span class="price" style="color: cornsilk"><?php echo e($forfait->prix); ?>€</span> <span class="per"></span></p>
            </div>
            <ul style="color:black; font-weight: bold; size: 7px; ">
              

                        <li><?php echo e($forfait->option1); ?></li>
                        <li><?php echo e($forfait->option2); ?></li>
                        <li><?php echo e($forfait->option3); ?></li>
                        <li><?php echo e($forfait->option4); ?></li>
                        <li><?php echo e($forfait->option5); ?></li>
            </ul>
            <p class="button text-center"><a href="#" class="btn btn-primary px-4 py-3">Get Offer</a></p>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
    </div>
</section>

<section class="ftco-section ftco-pricing">
    <div class="container">
        <div class="row justify-content-center pb-3">
  <div class="col-md-10 heading-section text-center ftco-animate">
      <span class="subheading">Tarifs</span>
    <h2 class="mb-4">Tarifs Coupe</h2>
  </div>
</div>
<div class="row">
    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3 ftco-animate">
        <div class="pricing-entry pb-5 text-center">
            <div>
                <h3  class="mb-4"><?php echo e($value->nom); ?></h3>
                <p><span class="price"><?php echo e($value->prix); ?>€</span> <span class="per"></span></p>
            </div>
            <ul>             
                        <li><?php echo e($value->option1); ?></li>
                        <li><?php echo e($value->option2); ?></li>
                        <li><?php echo e($value->option3); ?></li>
                        <li><?php echo e($value->option4); ?></li>
                        <li><?php echo e($value->option5); ?></li>
            </ul>
            <p class="button text-center"><a href="#" class="btn btn-primary px-4 py-3">Get Offer</a></p>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
    </div>
</section>

<section class="ftco-section ftco-pricing " style="background-image: url(<?php echo e(asset('front/images/barbregauche.jpg')); ?> );  background-size: cover;  background-repeat: no-repeat;">
 
    <div class="container">
        <div class="row justify-content-center pb-3">
  <div class="col-md-10 heading-section text-center ftco-animate">
 
    <h2 class="mb-4" style="color: blanchedalmond">Nos Forfaits</h2>
  </div>
</div>
<div class="row">
    <?php $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
    
    <div class="col-md-3 ftco-animate">
        <div class="pricing-entry pb-5 text-center">
            <div >
                <h2 class="mb-4" style="color: #340E0E; background-color: lightgrey; font-weight: bold;"><?php echo e($collection->nom); ?></h2>
                <p ><span style="color: cornsilk" class="price"><?php echo e($collection->prix); ?>€</span> <span class="per"></span></p>
            </div>
            <ul style="color:black; font-weight: bold; size: 7px; ">
              

                        <li style="color: black;"><?php echo e($collection->option1); ?></li>
                        <li><?php echo e($collection->option2); ?></li>
                        <li><?php echo e($collection->option3); ?></li>
                        <li><?php echo e($collection->option4); ?></li>
                        <li><?php echo e($collection->option5); ?></li>
            </ul>
            <p class="button text-center"><a href="#" class="btn btn-primary px-4 py-3">Get Offer</a></p>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
    </div>
</section>


 
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Cours\Projets\coiffeur\resources\views/tarifs.blade.php ENDPATH**/ ?>