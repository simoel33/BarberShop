@include('navbar')

<div>
 
    @yield('content')

</div>



@include('footer')